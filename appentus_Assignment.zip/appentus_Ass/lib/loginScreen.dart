import 'dart:io';
import 'homeScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:crypt/crypt.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/services.dart';


class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {

  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();

  List<String> credentials = ["E-mail", "Password"];
  bool correctIt = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(statusBarColor: Color(0xff810a3b10)));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Color(0xff0a3b10),
          title: Text("Appentus", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(30)),
                    color: Color(0xff510a3b10),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: List.generate(2, (index) {
                      return Padding(
                        padding: const EdgeInsets.all(25.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(credentials[index], style: TextStyle(color: correctIt ? Colors.red : Colors.black45),),
                            TextField(
                              key: Key(index.toString()),
                              controller: index == 0 ? email : password,
                              textAlign: TextAlign.start,
                              textInputAction: TextInputAction.next,
                              obscureText: index == 1 ? true : false,
                              style: TextStyle(
                                fontSize: 15,
                                decoration: TextDecoration.none,
                              ),
                              decoration: InputDecoration(
                                focusedBorder: InputBorder.none,
                                contentPadding: EdgeInsets.only(top: 5.0, left: 5.0),
                                errorBorder: InputBorder.none,
                                disabledBorder: InputBorder.none,
                              ),
                            ),
                          ],
                        ),
                      );
                    }) + [
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: TextButton(
                          onPressed: () {
                            Sign().then((value) {
                              if(value){
                                Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                                  return Map();}
                                ));
                              }
                              else{
                                setState(() {
                                  correctIt = true;
                                });
                              }
                            });
                          },
                          child: Text("Sign-in", style: TextStyle( fontSize: 20, color: Colors.white),),
                          style: TextButton.styleFrom(
                            primary: Colors.purple,
                            backgroundColor: Colors.black,
                          ),
                        )),
                      Padding(
                          padding: EdgeInsets.all(8.0),
                          child: TextButton(
                            onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                                return Profile();}
                              ));
                              },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text("New User Sign-up", style: TextStyle(fontSize: 20, color: Colors.white),),
                                SizedBox(width: 20,),
                                Icon(Icons.arrow_forward_ios_sharp, color: Colors.white,),
                              ],
                            ),
/*                style: TextButton.styleFrom(
                              primary: Colors.purple,
                              backgroundColor: Colors.green,
                            ),*/
                          ))
                    ]
                  ),
                ),
              ),
              Image.asset("assets/logo.png",),
            ],
          ),
        ),
      ),
    );
  }
  Future<bool> Sign() async{
    FlutterSecureStorage storage;
    storage = new FlutterSecureStorage();
    String? storedHashedPassword = await storage.read(key: email.text); // 2
    return Future.value(Crypt(storedHashedPassword!).match(password.text));
  }
}

class Profile extends StatefulWidget {

  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  List<TextEditingController> details = List.generate(6, (index) => TextEditingController());
  List<String> field = ["Name", "E-mail", "Password", "Re-enter Password", "Number"];

  final picker = ImagePicker();
  String? path;
  List<int> validate = [];

  Future getImage(bool camera) async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      await getApplicationDocumentsDirectory().then((value) {
        path = value.path;
        print(path);
      });
      File image = await File(pickedFile.path).copy('$path/DP.${pickedFile.path.substring(pickedFile.path.length - 3)}');
      path = image.path;
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xff0a3b10),
        ),
        body: Column(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.width * 0.5,
              color: Colors.black12,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.3,
                      height: MediaQuery.of(context).size.width * 0.3,
                      decoration: BoxDecoration(
                        color: Colors.deepOrange,
                        shape: BoxShape.circle,
                        border: Border.all(width: 3, color: Colors.orange),
                      ),
                      child: Center(
                          child: path != null ? ClipOval(
                              child: Image.file(File(path!))
                          ) :
                          Image.asset("assets/avatar.png")
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      getImage(true);
                      },
                    child: Text("Edit Photo", style: TextStyle(color: Colors.orange),),
                    style: TextButton.styleFrom(
                      backgroundColor: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                child: ListView(
                    children: List.generate(field.length, (index) {
                      return Padding(
                        padding: const EdgeInsets.only(left: 40, right: 40),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(field[index],
                                    style: TextStyle(
                                        color: validate.contains(index) ? Colors.red : Colors.black45
                                    ),),
                                  TextField(
                                    key: Key(index.toString()),
                                    maxLength: index == 4 ?  10 : 30,
                                    controller: details[index],
                                    textAlign: TextAlign.start,
                                    keyboardType: index == 4 ? TextInputType.phone : TextInputType.text,
                                    textInputAction: TextInputAction.next,
                                    obscureText: index == 2 || index == 3 ? true : false,
                                    style: TextStyle(
                                      fontSize: 15,
                                      decoration: TextDecoration.none,
                                    ),
                                    decoration: InputDecoration(
                                      focusedBorder: InputBorder.none,
                                      contentPadding: EdgeInsets.only(top: 5.0, left: 5.0),
                                      errorBorder: InputBorder.none,
                                      disabledBorder: InputBorder.none,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    }) + [
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: TextButton(
                          onPressed: () {
                            validate.clear();
                            for(int i = 0; i<details.length; i++){
                              if(details[i].text == ""){
                                validate.add(i);
                              }
                            }
                            if(details[2].text != details[3].text){
                              validate.add(2);
                              validate.add(3);
                            }
                            if(!details[1].text.contains("@")){
                              validate.add(1);
                            }
                            if(details[4].text.length != 10){
                              validate.add(4);
                            }
                            else {
                              SharedPreferences.getInstance().then((prefs) {
                                if(path != null){
                                  prefs.setString("ipath", path!);
                                }
                                prefs.setStringList("Id", [details[0].text, details[1].text, details[4].text]);
                              }).then((value) {
                                FlutterSecureStorage storage;
                                storage = new FlutterSecureStorage();
                                String  hashedPassword = Crypt.sha256(details[3].text).toString();
                                storage.write(key: details[1].text, value: hashedPassword).then((value) {
                                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context){
                                    return Map();
                                  }));
                                });
                              });
                            }
                            setState(() {});
                          },
                          child: Text("Sign-up", style: TextStyle( fontSize: 20, color: Colors.orange),),
                          style: TextButton.styleFrom(
                            backgroundColor: Colors.white,
                          ),
                        ),
                      )
                    ]
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/*
class MyClip extends CustomClipper<Rect> {
  Rect getClip(Size size) {
    return Rect.fromCircle(center: Offset(50, 50), radius: 30);
  }

  bool shouldReclip(oldClipper) {
    return true;
  }
}*/
