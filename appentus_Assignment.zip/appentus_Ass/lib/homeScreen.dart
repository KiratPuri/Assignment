import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'main.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/rendering.dart';
import 'package:geolocator/geolocator.dart';
import 'SecondScreen.dart';
import 'package:flutter/services.dart';

class Map extends StatefulWidget {
  const Map({Key? key}) : super(key: key);

  @override
  _MapState createState() => _MapState();
}

class _MapState extends State<Map> {

  bool dialog = true;
  String argument = "Loading...";
  double lat = 76.941611, long = -19.765380;
  late GoogleMapController mapController;

  void _determinePosition() async {

    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() {
        argument = 'Location services are disabled...';
      });
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        setState(() {
          argument = 'Location permissions are denied';
        });      }
    }

    if (permission == LocationPermission.deniedForever) {
      setState(() {
        argument = 'Location permissions are permanently denied, we cannot request permissions.';
      });
    }
    Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best).then((value) {
    });
    await Geolocator.getCurrentPosition().then((value) {
      setState(() {
        dialog = false;
        lat = value.latitude;
        long  =value.longitude;
        mapController.animateCamera(
          CameraUpdate.newCameraPosition(
            CameraPosition(
                target: LatLng(lat, long), zoom: 18.0, tilt: 22),
          ),
        );
      });
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    _determinePosition();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(statusBarColor: Color(0xff810a3b10)));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return SafeArea(
      child: Stack(
        children: [
          Scaffold(
          appBar: AppBar(
            backgroundColor: Color(0xff0a3b10),
            title: Text("Appentus"),
            flexibleSpace: Padding(
              padding: const EdgeInsets.only(right: 10),
              child: Container(
                alignment: Alignment.topRight,
                child: Image.asset("assets/logo1.png"),
              ),
            ),
          ),
              floatingActionButton: FloatingActionButton(
                backgroundColor: Colors.red,
                onPressed: () {
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context) { return Second();}));
                },
                child: Icon(Icons.list),
              ),
              body: GoogleMap(
                  onMapCreated: (GoogleMapController controller) {
                    mapController = controller;
                  },
                  mapType: MapType.satellite,
                  zoomControlsEnabled: false,
                  zoomGesturesEnabled: true,
            initialCameraPosition: CameraPosition(target: LatLng(lat,long), zoom: 7,),
            markers: {
              Marker(markerId: MarkerId("Your Position"),
                infoWindow: InfoWindow(
                  snippet: "Your Location",
                  title: "Your Location",
                ),
                icon: BitmapDescriptor.defaultMarker,
                position: LatLng(lat,long),
            )}
          )
        ),
          dialog ?  AlertDialog(
            title: Column(
              children: [
                Text(argument),
                SizedBox(height: 10,),
                CircularProgressIndicator(
                  color: Colors.deepOrange,
                  strokeWidth: 10,
                ),
              ],
            ),
          ) : Container(),
        ]
      ),
    );
  }
}
