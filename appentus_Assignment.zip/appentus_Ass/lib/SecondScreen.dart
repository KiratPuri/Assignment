import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:flutter/services.dart';


class Second extends StatefulWidget {
  const Second({Key? key}) : super(key: key);

  @override
  _SecondState createState() => _SecondState();
}

class _SecondState extends State<Second> {

  List<String> author = [], urls = [];
  List<int>  width = [], height = [];

  @override
  void initState() {
    // TODO: implement initState
    http.get(Uri.parse("https://picsum.photos/v2/list")).then((response) {
      print(response.body);
      jsonDecode(response.body).forEach((map){
        author.add(map["author"]);
        urls.add(map["download_url"]);
        width.add(map["width"]);
        height.add(map["height"]);
      });
    }).then((value) {
      setState(() {});
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(statusBarColor: Color(0xff810a3b10)));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0xff0a3b10),
        appBar: AppBar(
          backwardsCompatibility: false,
          backgroundColor: Colors.deepOrange,
          title: Text("Appentus", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),),
        ),
        body: StaggeredGridView.countBuilder(
          crossAxisCount: 4,
          itemCount: author.length,
          itemBuilder: (BuildContext context, int index) => new Container(
              color: Colors.deepOrange,
              child: Column(
                children: [
                  Expanded(
                      child: Image.network(urls[index])
                  ),
                  Text(author[index], style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),),
                ],
              )
          ),
          staggeredTileBuilder: (int index) =>
          new StaggeredTile.count(2, width[index] / height[index]),
          mainAxisSpacing: 4.0,
          crossAxisSpacing: 4.0,
        ),
      ),
    );
  }
}
