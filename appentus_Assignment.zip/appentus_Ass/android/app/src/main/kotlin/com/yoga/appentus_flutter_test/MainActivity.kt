package com.yoga.appentus_flutter_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
